<?php
    error_reporting(0);
    session_start();
    session_destroy();
    if($_SESSION['message']){
        $message=$_SESSION['message'];
        echo"<script type='text/javascript'>
        alert('$message');
        </script>";
        
        
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Technology Intergeration Project</title>
    <link rel="stylesheet" href="stylesforuniversity.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">
    <script src="https://kit.fontawesome.com/9cbe665fc5.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
    <section class ="sub-header">
        <nav> 
            <a href="UNIVERSITYPROJECT"><img src= "logo.png"></a>
            <div class = "nav-links" id="navLinks">
                <i class="fa fa-times" onclick="hideMenu()"></i>

                <ul>
                <ul>
                    <li><a href="university.html">HOME</a></li>
                    <li><a href="about.html">ABOUT</a></li>
                    <li><a href="contact.html">CONTACT</a></li>
                    <li><a href="admission.php">ADMISSION</a></li>
                    <li><a href="login.php">LOGIN</a> </li>
                </ul>

                </ul>
            </div>
            <i class="fa fa-bars" aria-hidden="true" onclick="showMenu()"></i>
        </nav>
        <h1>Admission Form</h1>

    </section>
        
    
        <div align="center" class="admission_form">
            <form action="data_check.php" method="post">
                <div class="adm_int">
                    <label class="label_text">Name</label>
                    <input class="input_deg" type="text" name="name">
                </div>
                <div class="adm_int">
                    <label class="label_text">Email</label>
                    <input class="input_deg" type="text" name="email">
                </div>
                <div class="adm_int">
                    <label class="label_text">Phone</label>
                    <input class="input_deg" type="text" name="phone">
                </div>
                <div class="adm_int">
                    <!-- <label class="label_text">What course you want to apply?</label>
                    <input class="input_deg" type="text" name="course"> -->
                    
                    <label class="label_text">Which course you want to apply for?</label>
                    <textarea class="input_txt" name="course"></textarea>
                    
                    
                </div>
                <div class="adm_int">
                    <input class="btn btn-primary" id="submit"   type="submit" value="Apply" name="apply">
                </div>
            </form>
        </div>
    </body>

    <!--footer-->
    <section class="footer">
        <h3 style="text-align:center">EDUFORD UNIVERSITY</h3>
        <p style="font-size: larger;font-family: 'Times New Roman', Times, serif;">Get the perfect start to your dream career by joining the Institution of Eminence</p>

        <div class="icons">
            <h4>Connect with Eduford</h4>
            <a href="https://facebook.com"><i class="fa fa-facebook"></i></a>
            <a href="https://www.instagram.com"><i class="fa fa-instagram"></i></a>
            <a href="https://www.twitter.com"><i class="fa fa-twitter"></i></a>
            <a href="https://www.linkedin.com"><i class="fa fa-linkedin"></i></a>
        </div>
    </section>