<?php
$name=$_POST['name']; 
$visitor__email =$_POST['email']; 
$subject=$_POST['subject'];
 $message=$_POST['message']; 

 $email_from='info@BhavikaVarshaReena.com';

 $email_subject='new form submission';

 $email_body="User Name : $name.\n".
              "User Email : $visitor_email.\n".
              "Subject : $subject.\n".
              "User message : $message.\n".;

$to='farzispam125@gmail.com';

$headers="from: $email_from \r\n";

$headers .="Reply-To : $visitor_email\r\n";

mail($to,$email_subject,$email_body,$headers);
header("Location : contact.html");

 ?>


