<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Technology Intergeration Project</title>
    <link rel="stylesheet" href="stylesforuniversity.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">
    <script src="https://kit.fontawesome.com/9cbe665fc5.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    

</head>
<body>
    <section class ="sub-header">
        <nav> 
            <a href="UNIVERSITYPROJECT"><img src= "logo.png"></a>
            <div class = "nav-links" id="navLinks">
                <i class="fa fa-times" onclick="hideMenu()"></i>

                <ul>
                <ul>
                    <li><a href="university.html">HOME</a></li>
                    <li><a href="about.html">ABOUT</a></li>
                    <li><a href="contact.html">CONTACT</a></li>
                    <li><a href="admission.php">ADMISSION</a></li>
                    <li><a href="login.php">LOGIN</a> </li>
                </ul>

                </ul>
            </div>
            <i class="fa fa-bars" aria-hidden="true" onclick="showMenu()"></i>
        </nav>
        <h1>Login</h1>

    </section>

    <center>
        <div>
            <form class="login-form" action="login_check.php" method="POST" class="login_form">
                <div class="form_deg">
                <center class="title_deg">
				<b>Login Form</b>

				<h4>
					<?php 

					error_reporting(0);
					session_start();
					session_destroy();
			
				echo $_SESSION['loginMessage'];
			

					?>

				</h4>
			    </center>
                    <label class="label_deg">Username</label>
                    <input type="text" name="username">
                </div>
                <div>
                    <label class="label_deg">Password</label>
                    <input type="password" name="password">
                </div>
                <div>
                    <input type="submit" name="submit" value="Login" class="btn btn-primary">
                </div>
            </form>
        </div>
    </center>

    <!-- footer -->
    <section class="footer" >
        <h3 style="text-align:center">EDUFORD UNIVERSITY</h3>
        <p style="font-size: larger;font-family: 'Times New Roman', Times, serif;">Get the perfect start to your dream career by joining the Institution of Eminence</p>
        <div class="icons">
            <h4>Connect with Eduford</h4>
            <a href="https://facebook.com"><i class="fa fa-facebook"></i></a>
            <a href="https://www.instagram.com"><i class="fa fa-instagram"></i></a>
            <a href="https://www.twitter.com"><i class="fa fa-twitter"></i></a>
            <a href="https://www.linkedin.com"><i class="fa fa-linkedin"></i></a>
        </div>
    </section>
    <!--javascript for tooggle menu-->
    <script>
        var navLinks= document.getElementById("navLinks");
        function showMenu(){
            navLinks.style.right="0";
        }
        function hideMenu(){
            navLinks.style.right="-200px";
        }
    </script>