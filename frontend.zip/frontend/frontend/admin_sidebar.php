



<header class="header">
		
		<a href="">Admin Dashboard</a>

		<div class="logout">
			
			<a href="logout.php" class="btn btn-primary">Logout</a>

		</div>
		<style>
			.sidecontent{
				position:sticky;
			}
		</style>


	</header>

    <div class="sidecontent">
	<aside>
		
		<ul>
			
			<li>
				<a href="addmissions.php">Admission</a>
			</li>

			<li>
				<a href="add_student.php">Add Student</a>
			</li>

			<li>
				<a href="">View Student</a>
			</li>

			<!-- <li>
				<a href="">Add Teacher</a>
			</li>

			<li>
				<a href="">View Teacher</a>
			</li> -->
			<li>
				<a href="">Add Courses</a>
			</li>
			<li>
				<a href="">View Courses</a>
			</li>


		</ul>


	</aside>
	</div>

